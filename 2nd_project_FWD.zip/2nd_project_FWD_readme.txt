I add comment to my code in notebook so most of the question i need to check i answer it there.
I start the project with 2 datasets ever dataset have differant features except 2 col (id ,name)
I merge them by id to make the analysis more easier 
Most of the question i asked i made histogram to answer it with 
I removed %matplotlib inline and the code run correctly and in the error you point on it in your reviwe i didn not wright this line so i checked it changed when i save the notebook as python file

